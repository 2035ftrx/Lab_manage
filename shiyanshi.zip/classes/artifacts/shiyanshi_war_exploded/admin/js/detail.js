﻿$(function () {
 
    $(".zoom").jqzoom();
  
});
