var online=new Array();
document.write("<script language=\"javascript\" src=\"http://webpresence.qq.com/getonline?Type=1&1762116301 :136569269 :\" charset=\"utf-8\" type=\"text/javascript\"></script>");
document.write("<script language=\"javascript\" src=\"http://code2.54kefu.net/kefu/url.js\" charset=\"utf-8\" type=\"text/javascript\"></script>");
document.write("<script language=\"javascript\" src=\"http://code2.54kefu.net/kefu/js/74/793074_code.js\" charset=\"utf-8\" type=\"text/javascript\"></script>");
